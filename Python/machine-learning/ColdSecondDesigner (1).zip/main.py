import numpy

f = open('voting_record_dump109.txt')
mylist = list(f)


final_data=[]
for i in mylist:
  name=i.split()[0]
  data=i.split()[3:]
  data=numpy.array(data,int)  #just to change everything ti int 
  data=list(data)
  final_data.append((name,data))
print(final_data[3],len(final_data))  #you can extract each politican from here 
#there are 99 politicans